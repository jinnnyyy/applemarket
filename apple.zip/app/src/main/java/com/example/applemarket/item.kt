package com.example.applemarket

class item(var image: Int, var title: String, var detail: String, var person:String, var number: String, var where: String, var like:Int, var chat: Int)